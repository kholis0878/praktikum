package com.example.wisata

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
